package prog;

public class Auto {
	private int id;
	public Auto(int id) {
		this.id=id;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}
	

}
